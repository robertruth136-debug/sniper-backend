const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

app.get("/", (req, res) => {
  res.json({ status: "Sniper Intelligence Backend Running" });
});

app.get("/signal", (req, res) => {
  const pair = req.query.pair || "AUD/CAD";
  const timeframe = req.query.timeframe || "S15";
  const market = req.query.market || "REGULAR";

  const directions = ["BUY", "SELL"];
  const signal = directions[Math.floor(Math.random() * directions.length)];
  const accuracy = Math.floor(Math.random() * 8) + 90;

  let duration = 15;
  if (timeframe === "S5") duration = 5;
  if (timeframe === "S30") duration = 30;
  if (timeframe === "M1") duration = 60;

  res.json({
    pair,
    market,
    timeframe,
    signal,
    accuracy,
    duration,
    signalType: "Platinum"
  });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Backend running on port ${PORT}`);
});
