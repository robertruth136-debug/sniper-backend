/**
 * RUZY PLUS – Trading Bot Backend
 * Node.js + Express
 */

const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

/* ===== UTIL FUNCTIONS ===== */
function fakeRSI() {
  return Math.floor(20 + Math.random() * 60);
}

function fakeEMA() {
  return Math.random() > 0.5 ? "bullish" : "bearish";
}

const timeframeMap = {
  S5: 5,
  S10: 10,
  S15: 15,
  S30: 30,
  "1min": 60,
  "5min": 300,
  "10min": 600
};

/* ===== HEALTH CHECK ===== */
app.get("/", (req, res) => {
  res.send("RUZY PLUS backend is running ✅");
});

/* ===== SIGNAL API ===== */
app.post("/signal", (req, res) => {
  const { pair, timeframe } = req.body;

  if (!pair || !timeframe) {
    return res.status(400).json({ error: "Missing pair or timeframe" });
  }

  const rsi = fakeRSI();
  const ema = fakeEMA();

  const buy = rsi < 35 && ema === "bullish";
  const sell = rsi > 65 && ema === "bearish";

  const signal =
    buy || (!sell && Math.random() > 0.5) ? "BUY" : "SELL";

  const accuracy = Math.min(95, 80 + Math.abs(50 - rsi));
  const expiry = timeframeMap[timeframe] || 15;

  res.json({
    pair,
    timeframe,
    signal,
    accuracy,
    expiry,
    generatedAt: new Date().toISOString()
  });
});

/* ===== START SERVER ===== */
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🤖 RUZY PLUS backend running on port ${PORT}`);
});
